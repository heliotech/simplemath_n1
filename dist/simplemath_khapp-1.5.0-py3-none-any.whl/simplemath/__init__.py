from . fancy import add as fancyadd
from . fancy import sub as fancysub
from . fancy import mul as fancymul
from . fancy import div as fancydiv

from . pyadvanced import add as advancedadd
from . pyadvanced import sub as advancedsub
from . pyadvanced import mul as advancedmul
from . pyadvanced import div as advanceddiv

from . simple import add as simpleadd
from . simple import sub as simplesub
from . simple import mul as simplemul
from . simple import div as simplediv

# from . import mutils
# from . import smlib
from .smlib import Animals, Markers
